from django.shortcuts import render

# Create your views here.
def Index(request):
    return render(request, 'Index.html')

def Login(request):
    return render(request, 'Login.html')